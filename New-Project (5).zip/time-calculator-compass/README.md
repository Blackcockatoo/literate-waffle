# Temporal Mathematics Compass

A special time calculator compass based on circular numeric patterns and mathematical principles. This interactive application visualizes temporal-mathematical relationships through dynamic, interactive visualizations.

![Time Calculator Compass](./preview.png)

## Features

### Time Compass

The Time Compass visualization combines:
- A traditional clock face with digital time readout
- Mathematical progressions around a circular perimeter
- Interactive rotation controls for exploring numerical patterns
- Temporal calculation capabilities that display mathematical relationships

### Clockwise Node Pattern (SRG Visualization)

The Node Pattern displays:
- Starburst patterns emanating from a central node
- Color-coded SRG (Spatial Relationship Graph) patterns in red, blue, and black
- Interactive rotation and animation controls
- Procedurally generated node connections that follow mathematical principles

### Colored Circle Distribution

The Circle Pattern provides:
- Multivariate circle distributions with harmonically related positions
- Spiral pattern generation based on golden ratio principles
- Random distribution mode for exploring stochastic relationships
- Floating pattern mode with organized symmetrical arrangements

## Mathematical Concepts

This visualization tool explores several mathematical principles:

- **Modular Pattern Detection**: Identify repeating modular patterns within circular sequences
- **Harmonic Distribution Analysis**: Assess spacing and periodicity between digit occurrences
- **Prime Position Mapping**: Locate and visualize prime-indexed digits within sequences
- **Symmetric Pattern Identification**: Explore reflective or palindromic sequences
- **Fibonacci Spiral Projection**: Map sequences onto golden ratio spirals

## Implementation Details

Built using:
- React and TypeScript for robust component architecture
- SVG for high-fidelity vector graphics
- TailwindCSS for responsive styling and animation
- Custom animation classes for smooth transitions

## Getting Started

```bash
# Install dependencies
bun install

# Start the development server
bun run dev
```

## Usage

1. Select between Time Compass, Node Pattern, and Circle Pattern modes
2. Interact with each visualization through the provided controls
3. Observe the relationships between time, mathematical patterns, and visual representations
4. Use the calculation features to explore temporal-mathematical correlations

## Inspiration

This project was inspired by circular numeric analysis and temporal mathematics, with visualizations based on concepts from:

- Chronological number theory
- Circular harmonic relationships
- Spatial node distribution patterns
- Golden ratio and Fibonacci sequence relationships

## License

MIT License
