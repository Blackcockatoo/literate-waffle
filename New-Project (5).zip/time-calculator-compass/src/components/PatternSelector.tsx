interface PatternSelectorProps {
  selectedPattern: string;
  setSelectedPattern: (pattern: string) => void;
}

const PatternSelector = ({ selectedPattern, setSelectedPattern }: PatternSelectorProps) => {
  const patterns = [
    { id: 'timeCompass', name: 'Time Compass' },
    { id: 'nodePattern', name: 'Node Pattern' },
    { id: 'circlePattern', name: 'Circle Pattern' }
  ];

  return (
    <div className="flex gap-4 flex-wrap justify-center">
      {patterns.map((pattern) => (
        <button
          key={pattern.id}
          onClick={() => setSelectedPattern(pattern.id)}
          className={`px-4 py-2 rounded-full transition-all ${
            selectedPattern === pattern.id
              ? 'bg-purple-600 text-white'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
        >
          {pattern.name}
        </button>
      ))}
    </div>
  );
};

export default PatternSelector;
