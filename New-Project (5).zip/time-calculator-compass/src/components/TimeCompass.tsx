import { useState, useEffect } from 'react';

// Adjust SVG size based on screen width for better mobile experience
const useMobileSize = () => {
  const [size, setSize] = useState({
    width: typeof window !== 'undefined' ? Math.min(window.innerWidth - 40, 500) : 500,
    height: typeof window !== 'undefined' ? Math.min(window.innerWidth - 40, 500) : 500,
  });

  useEffect(() => {
    const handleResize = () => {
      const newSize = Math.min(window.innerWidth - 40, 500);
      setSize({ width: newSize, height: newSize });
    };

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial size

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return size;
};

const TimeCompass = () => {
  const [rotation, setRotation] = useState(0);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isCalculating, setIsCalculating] = useState(false);
  const [currentMode, setCurrentMode] = useState<'time' | 'compass' | 'calculator'>('time');
  const [selectedNumberString, setSelectedNumberString] = useState<'blue' | 'red' | 'black'>('blue');
  const [apiKey, setApiKey] = useState('');
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [apiStatus, setApiStatus] = useState<'disconnected' | 'connected' | 'error'>('disconnected');
  const [apiModel, setApiModel] = useState<'gbt-3' | 'gbt-4'>('gbt-3');

  // Get responsive size for SVG
  const svgSize = useMobileSize();

  // Number strings provided by the user
  const numberStrings = {
    blue: '012776329785893036118967145479098334781325217074992143965631',
    red: '113031491493585389543778774590997079619617525721567332336510',
    black: '011235831459437077415617853819099875279651673033695493257291'
  };

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Enhance readability of numbers on the compass
  const enhanceNumberDisplay = (value: string) => {
    // Apply different styling or formatting based on the digit
    const valueNum = parseInt(value, 10);
    if (valueNum <= 3) {
      return <tspan className="font-bold">{value}</tspan>;
    } else if (valueNum >= 7) {
      return <tspan className="font-semibold">{value}</tspan>;
    }
    return value;
  };

  // Generate points around a circle from the number string
  const generatePointsFromString = (
    numberString: string,
    radius: number,
    centerX: number,
    centerY: number
  ) => {
    const points = [];
    const count = numberString.length;

    for (let i = 0; i < count; i++) {
      const angle = (i * 2 * Math.PI / count) + rotation;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);

      // Calculate a size multiplier based on the digit value for visual emphasis
      const digitValue = parseInt(numberString.charAt(i), 10);
      const sizeMultiplier = 0.8 + (digitValue / 10) * 0.6; // Range from 0.8 to 1.4 based on digit

      points.push({
        x,
        y,
        value: numberString.charAt(i),
        position: i,
        size: sizeMultiplier,
      });
    }
    return points;
  };

  // Calculate center points for the SVG
  const centerX = svgSize.width / 2;
  const centerY = svgSize.height / 2;
  const radius = Math.min(centerX, centerY) * 0.85; // Slightly reduced to fit on mobile

  // Get the current number string based on selection
  const currentNumberString = numberStrings[selectedNumberString];

  // Generate points based on the selected number string
  const points = generatePointsFromString(currentNumberString, radius, centerX, centerY);

  // GBT API validation - checks if the API key has the correct format for GBT
  const validateGbtApiKey = (key: string): boolean => {
    // GBT API keys typically start with "gbt-" followed by alphanumeric characters
    return /^gbt-[a-zA-Z0-9]{24,48}$/.test(key);
  };

  // Simulate API connection test
  const testApiConnection = async (key: string): Promise<boolean> => {
    // This would be a real API request in production
    console.log('Testing GBT API connection with key:', key);

    // Simulate API response delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // For demo, consider valid if it follows the format
    return validateGbtApiKey(key);
  };

  const startCalculation = () => {
    setIsCalculating(true);

    // Use GBT API for calculations if connected
    if (apiStatus === 'connected') {
      console.log(`Using GBT API (${apiModel}) for temporal pattern calculation`);
      // In a real implementation, you would make an actual GBT API call here
    }

    setTimeout(() => {
      setIsCalculating(false);
    }, 2000);
  };

  const getColorForNumberString = () => {
    switch (selectedNumberString) {
      case 'blue': return '#3b82f6';
      case 'red': return '#ef4444';
      case 'black': return '#4b5563';
      default: return '#3b82f6';
    }
  };

  const handleApiKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Reset status while testing
    setApiStatus('disconnected');

    try {
      // Basic validation first
      if (!validateGbtApiKey(apiKey)) {
        alert('Invalid GBT API key format. Keys should start with "gbt-" followed by 24-48 characters.');
        setApiStatus('error');
        return;
      }

      // Test API connection
      const isConnected = await testApiConnection(apiKey);

      if (isConnected) {
        setApiStatus('connected');
        setShowApiKeyInput(false);
        alert(`GBT API Key successfully connected: ${apiKey.substring(0, 6)}...${apiKey.substring(apiKey.length - 4)}`);
      } else {
        setApiStatus('error');
        alert('Could not connect to GBT API. Please check your key and try again.');
      }
    } catch (error) {
      console.error('Error testing API connection:', error);
      setApiStatus('error');
      alert('Error connecting to GBT API. Please try again later.');
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between">
      {/* Current time display in a more mobile-friendly layout */}
      <div className="w-full flex justify-center mb-2">
        <div className="bg-gray-800 rounded-lg px-4 py-2 shadow-md border border-gray-700 text-center w-full max-w-[200px]">
          <div className="text-sm text-gray-400">Current Time</div>
          <div className="text-xl font-mono font-bold">
            {currentTime.toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* Mode selector buttons in horizontal layout */}
      <div className="flex justify-center gap-2 mb-2 w-full px-2">
        <button
          onClick={() => setCurrentMode('time')}
          className={`px-3 py-2 rounded-lg transition-all shadow-md flex-1 ${
            currentMode === 'time'
              ? 'bg-blue-600 text-white font-medium'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
          }`}
        >
          Time
        </button>
        <button
          onClick={() => setCurrentMode('compass')}
          className={`px-3 py-2 rounded-lg transition-all shadow-md flex-1 ${
            currentMode === 'compass'
              ? 'bg-purple-600 text-white font-medium'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
          }`}
        >
          Compass
        </button>
        <button
          onClick={() => setCurrentMode('calculator')}
          className={`px-3 py-2 rounded-lg transition-all shadow-md flex-1 ${
            currentMode === 'calculator'
              ? 'bg-green-600 text-white font-medium'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
          }`}
        >
          Calculator
        </button>
      </div>

      {/* Number string title */}
      <div className="w-full text-center mb-1">
        <div
          className="mx-auto text-center py-1 px-4 text-sm font-medium rounded-full"
          style={{ color: getColorForNumberString() }}
        >
          {selectedNumberString.toUpperCase()} Number String: {currentNumberString.length} digits
        </div>
      </div>

      {/* Main visualization */}
      <div className="perspective-container w-full">
        <svg
          width={svgSize.width}
          height={svgSize.height}
          viewBox={`0 0 ${svgSize.width} ${svgSize.height}`}
          className={`
            ${isCalculating ? 'glow-effect' : ''}
            ${currentMode === 'compass' ? 'rotateY-animation' : ''}
            visualization-transition
          `}
        >
          {/* Outer circle */}
          <circle
            cx={centerX}
            cy={centerY}
            r={radius}
            fill="none"
            stroke={getColorForNumberString()}
            strokeWidth="2.5"
            className="time-circle"
          />

          {/* Inner circles for visual effect */}
          <circle
            cx={centerX}
            cy={centerY}
            r={radius * 0.8}
            fill="none"
            stroke={isCalculating ? "#ff9f43" : "#4ade80"}
            strokeWidth="1.5"
            strokeDasharray="3,3"
            className="time-circle"
          />
          <circle
            cx={centerX}
            cy={centerY}
            r={radius * 0.6}
            fill="none"
            stroke={isCalculating ? "#ff9f43" : "#4ade80"}
            strokeWidth="1.5"
            strokeDasharray="3,3"
            className="time-circle"
          />

          {/* Center point */}
          <circle
            cx={centerX}
            cy={centerY}
            r="10"
            fill={getColorForNumberString()}
            className={isCalculating ? 'calculator-button-pulse' : ''}
          />

          {/* Lines from center to each point */}
          {(isCalculating || currentMode === 'compass' || currentMode === 'calculator') &&
            points.map((point, index) => (
              <line
                key={`line-${index}`}
                x1={centerX}
                y1={centerY}
                x2={point.x}
                y2={point.y}
                stroke={`hsl(${(index * 360 / points.length) % 360}, 70%, 60%)`}
                strokeWidth="1.5"
                strokeOpacity={currentMode === 'calculator' ? "0.4" : "0.8"}
              />
            ))}

          {/* Numbers around the circle - enhanced styling */}
          {points.map((point, index) => {
            // Determine background fill based on the digit value
            const value = parseInt(point.value, 10);
            const bgOpacity = (value / 9) * 0.6 + 0.1; // Range from 0.1 to 0.7

            return (
              <g key={`point-${index}`}>
                {/* Background circle for the number */}
                <circle
                  cx={point.x}
                  cy={point.y}
                  r="14"
                  fill={getColorForNumberString()}
                  fillOpacity={bgOpacity}
                  stroke={getColorForNumberString()}
                  strokeWidth="1"
                  strokeOpacity="0.3"
                />

                {/* Number text with enhanced display */}
                <text
                  x={point.x}
                  y={point.y}
                  textAnchor="middle"
                  dominantBaseline="central"
                  fill={isCalculating ? "white" : "white"}
                  fontSize={14 * (point.size || 1)}
                  fontWeight={value > 5 ? "bold" : "normal"}
                >
                  {enhanceNumberDisplay(point.value)}
                </text>

                {/* Outer highlight ring that animates */}
                <circle
                  cx={point.x}
                  cy={point.y}
                  r="3"
                  fill={isCalculating ? "#ff9f43" : getColorForNumberString()}
                  className={currentMode === 'calculator' ? 'calculator-button-pulse' : ''}
                  style={{
                    animationDelay: `${index * 100}ms`,
                    animationDuration: '1.5s'
                  }}
                />

                {/* Show position index for every 5th digit for reference - only on larger screens */}
                {index % 5 === 0 && svgSize.width > 400 && (
                  <text
                    x={point.x + (point.x > centerX ? 20 : -20)}
                    y={point.y + (point.y > centerY ? 20 : -20)}
                    fill="#a1a1aa"
                    fontSize="10"
                    fontWeight="bold"
                    textAnchor={point.x > centerX ? "start" : "end"}
                  >
                    {index}
                  </text>
                )}
              </g>
            );
          })}

          {/* Time indicator */}
          {currentMode === 'time' && (
            <>
              {/* Hour hand */}
              <line
                x1={centerX}
                y1={centerY}
                x2={centerX + Math.sin(currentTime.getHours() * Math.PI / 6) * radius * 0.5}
                y2={centerY - Math.cos(currentTime.getHours() * Math.PI / 6) * radius * 0.5}
                stroke="#f87171"
                strokeWidth="3"
                strokeLinecap="round"
              />

              {/* Minute hand */}
              <line
                x1={centerX}
                y1={centerY}
                x2={centerX + Math.sin(currentTime.getMinutes() * Math.PI / 30) * radius * 0.7}
                y2={centerY - Math.cos(currentTime.getMinutes() * Math.PI / 30) * radius * 0.7}
                stroke="#60a5fa"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Second hand */}
              <line
                x1={centerX}
                y1={centerY}
                x2={centerX + Math.sin(currentTime.getSeconds() * Math.PI / 30) * radius * 0.8}
                y2={centerY - Math.cos(currentTime.getSeconds() * Math.PI / 30) * radius * 0.8}
                stroke="#f59e0b"
                strokeWidth="1"
                strokeLinecap="round"
              />
            </>
          )}

          {/* GBT API indicator - only shown when connected */}
          {apiStatus === 'connected' && (
            <g>
              <rect
                x={centerX - 70}
                y={20}
                width="140"
                height="24"
                rx="12"
                fill="#10b981"
                fillOpacity="0.2"
              />
              <text
                x={centerX}
                y={35}
                textAnchor="middle"
                fill="#10b981"
                className="font-bold"
                fontSize="12"
              >
                GBT {apiModel.toUpperCase()} Connected
              </text>
              <circle
                cx={centerX - 55}
                cy={35}
                r="5"
                fill="#10b981"
                className="animate-pulse"
              />
            </g>
          )}
        </svg>
      </div>

      {/* Number selector buttons */}
      <div className="flex justify-center gap-2 w-full mt-2">
        <button
          onClick={() => setSelectedNumberString('blue')}
          className={`px-2 py-2 rounded-lg transition-all shadow-md flex-1 ${
            selectedNumberString === 'blue'
              ? 'bg-blue-600 text-white font-medium border border-blue-700'
              : 'bg-gray-800 text-blue-300 hover:bg-gray-700 border border-blue-900'
          }`}
        >
          Blue<span className="hidden sm:inline"> Numbers</span>
        </button>
        <button
          onClick={() => setSelectedNumberString('red')}
          className={`px-2 py-2 rounded-lg transition-all shadow-md flex-1 ${
            selectedNumberString === 'red'
              ? 'bg-red-600 text-white font-medium border border-red-700'
              : 'bg-gray-800 text-red-300 hover:bg-gray-700 border border-red-900'
          }`}
        >
          Red<span className="hidden sm:inline"> Numbers</span>
        </button>
        <button
          onClick={() => setSelectedNumberString('black')}
          className={`px-2 py-2 rounded-lg transition-all shadow-md flex-1 ${
            selectedNumberString === 'black'
              ? 'bg-gray-600 text-white font-medium border border-gray-700'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
          }`}
        >
          Black<span className="hidden sm:inline"> Numbers</span>
        </button>
      </div>

      {/* API buttons */}
      <div className="w-full flex justify-center mt-2">
        <button
          onClick={() => setShowApiKeyInput(!showApiKeyInput)}
          className={`px-4 py-2 rounded-lg transition-all shadow-md border w-full max-w-[200px] ${
            apiStatus === 'connected'
              ? 'bg-green-600 text-white border-green-700 font-medium'
              : apiStatus === 'error'
                ? 'bg-red-600 text-white border-red-700 font-medium'
                : 'bg-yellow-600 hover:bg-yellow-700 text-white border-yellow-700 font-medium'
          }`}
        >
          {apiStatus === 'connected'
            ? 'GBT API Connected'
            : showApiKeyInput
              ? 'Hide GBT API Options'
              : 'GBT API Options'}
        </button>
      </div>

      {/* API Key input popup */}
      {showApiKeyInput && (
        <div className="fixed inset-0 z-10 flex items-center justify-center bg-black bg-opacity-70">
          <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 w-80 mx-4">
            <h3 className="text-lg font-medium text-white mb-3 flex justify-between items-center">
              <span>GBT API Integration</span>
              <button
                onClick={() => setShowApiKeyInput(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </h3>
            <form onSubmit={handleApiKeySubmit} className="flex flex-col gap-3">
              <div>
                <label htmlFor="apiKey" className="text-sm text-gray-300 block mb-1">
                  GBT API Key
                </label>
                <input
                  id="apiKey"
                  type="text"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="gbt-xxxxxxxxxxxxxxxxxxxxxxxx"
                  className="px-3 py-2 bg-gray-700 text-white rounded-md w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Enter your GBT API key to enable advanced temporal calculations
                </p>
              </div>

              <div className="mt-2">
                <label className="text-sm text-gray-300 block mb-1">
                  GBT Model
                </label>
                <div className="flex gap-3">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="apiModel"
                      checked={apiModel === 'gbt-3'}
                      onChange={() => setApiModel('gbt-3')}
                      className="mr-2"
                    />
                    <span className="text-gray-300">GBT-3</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="apiModel"
                      checked={apiModel === 'gbt-4'}
                      onChange={() => setApiModel('gbt-4')}
                      className="mr-2"
                    />
                    <span className="text-gray-300">GBT-4</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-between mt-3">
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg"
                >
                  Connect API
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setApiKey('');
                    setApiStatus('disconnected');
                  }}
                  className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
                >
                  Reset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bottom control buttons */}
      <div className="flex justify-between w-full mt-4 gap-2">
        <button
          onClick={() => setRotation(prev => prev + (Math.PI / 30))}
          className="px-2 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white shadow-lg font-medium border border-blue-700 flex-1"
        >
          Rotate Clockwise
        </button>

        <button
          onClick={() => setRotation(prev => prev - (Math.PI / 30))}
          className="px-2 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg text-white shadow-lg font-medium border border-purple-700 flex-1"
        >
          Rotate Counter-Clockwise
        </button>
      </div>

      {/* Calculation button - full width */}
      <button
        onClick={startCalculation}
        className={`w-full mt-2 py-3 rounded-lg text-white font-bold transition-all shadow-lg ${
          isCalculating
            ? 'bg-red-600 animate-pulse cursor-not-allowed border border-red-800'
            : apiStatus === 'connected'
              ? 'bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 border border-green-700'
              : 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 border border-purple-700'
        }`}
        disabled={isCalculating}
      >
        {isCalculating
          ? 'Calculating...'
          : apiStatus === 'connected'
            ? `Calculate with ${apiModel.toUpperCase()}`
            : 'Calculate Temporal Pattern'}
      </button>

      {/* Number sequence display - enhanced for mobile */}
      <div className="w-full bg-gray-800 bg-opacity-90 p-2 rounded-lg mt-2 border border-gray-700 shadow-lg max-h-20 overflow-y-auto">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-400">Number Sequence:</span>
          <span className="text-xs text-gray-400">{currentNumberString.length} digits</span>
        </div>
        <p className="text-xs font-mono text-center tracking-wide" style={{ color: getColorForNumberString() }}>
          {currentNumberString}
        </p>
      </div>
    </div>
  );
};

export default TimeCompass;
