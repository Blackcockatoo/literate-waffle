import { useState, useEffect, useMemo } from 'react';

// Define proper types to fix TypeScript errors
interface Point {
  x: number;
  y: number;
  value?: number;
}

interface Line {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

const ClockwiseNodePattern = () => {
  const [selectedColor, setSelectedColor] = useState<'red' | 'blue' | 'black'>('red');
  const [points, setPoints] = useState<Point[]>([]);
  const [lines, setLines] = useState<Line[]>([]);
  const [animationActive, setAnimationActive] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [apiKey, setApiKey] = useState('');
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [apiStatus, setApiStatus] = useState<'disconnected' | 'connected' | 'error'>('disconnected');

  // Number strings that can be used for patterns if needed
  const numberStrings = useMemo(() => ({
    blue: '012776329785893036118967145479098334781325217074992143965631',
    red: '113031491493585389543778774590997079619617525721567332336510',
    black: '011235831459437077415617853819099875279651673033695493257291'
  }), []);

  const centerX = 250;
  const centerY = 250;

  // Generate a starburst pattern similar to the examples in the images
  useEffect(() => {
    const generateStarburstPattern = () => {
      const centerPoint: Point = { x: centerX, y: centerY };
      const newPoints: Point[] = [centerPoint];
      const newLines: Line[] = [];

      // Number of branches - use the first digits of the number string for variation
      const numberString = numberStrings[selectedColor];
      const branchCount = 20 + (Number(numberString[0]) + Number(numberString[1]));

      for (let i = 0; i < branchCount; i++) {
        // Create an angle for this branch, evenly distributed around the circle
        const baseAngle = (i / branchCount) * Math.PI * 2;
        // Add some randomness to the angle based on the number string
        const angleVariation = (Number(numberString[i % numberString.length]) / 10) * 0.3;
        const angle = baseAngle + angleVariation - 0.15 + rotationAngle;

        // Length of main branch - vary based on the number string
        const lengthModifier = (Number(numberString[(i + 5) % numberString.length]) / 5) + 0.5;
        const mainLength = 70 + (Math.random() * 150 * lengthModifier);
        const endX = centerX + Math.cos(angle) * mainLength;
        const endY = centerY + Math.sin(angle) * mainLength;

        // Store digit value for visual enhancement
        const digitValue = Number(numberString[i % numberString.length]);
        newPoints.push({ x: endX, y: endY, value: digitValue });
        newLines.push({ x1: centerX, y1: centerY, x2: endX, y2: endY });

        // Add nodes along the branch based on the number string
        const nodeCount = 1 + (Number(numberString[(i + 10) % numberString.length]) % 3);
        let lastX = centerX;
        let lastY = centerY;

        for (let j = 0; j < nodeCount; j++) {
          // Position along the branch (0-1) - vary based on number string
          const posModifier = (Number(numberString[(i + j + 15) % numberString.length]) / 10) + 0.5;
          const pos = ((j + 1) / (nodeCount + 1)) * posModifier;
          const nodeX = centerX + Math.cos(angle) * mainLength * pos;
          const nodeY = centerY + Math.sin(angle) * mainLength * pos;

          // Store the digit value for this node for visual enhancements
          const nodeDigitValue = Number(numberString[(i * 3 + j) % numberString.length]);
          newPoints.push({ x: nodeX, y: nodeY, value: nodeDigitValue });
          newLines.push({ x1: lastX, y1: lastY, x2: nodeX, y2: nodeY });

          lastX = nodeX;
          lastY = nodeY;
        }

        // Connect the last node to the end
        if (nodeCount > 0) {
          newLines.push({ x1: lastX, y1: lastY, x2: endX, y2: endY });
        }
      }

      setPoints(newPoints);
      setLines(newLines);
    };

    generateStarburstPattern();
  }, [selectedColor, rotationAngle, numberStrings]);

  // The rest of the component code remains the same

  // Start animation
  const startAnimation = () => {
    setAnimationActive(true);

    // Simulate API request with the API key if provided
    if (apiStatus === 'connected') {
      console.log(`Simulating API request for SRG pattern with key: ${apiKey}`);
      // In a real implementation, you would make an actual API call here
    }

    // Animate by rotating the pattern
    const startTime = Date.now();
    const duration = 4000; // 4 seconds
    const initialRotation = rotationAngle;
    const totalRotation = Math.PI / 2; // 90 degrees rotation

    const animate = () => {
      const now = Date.now();
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Use easing function for smoother animation
      const easeProgress = 1 - Math.pow(1 - progress, 3); // Ease out cubic

      setRotationAngle(initialRotation + totalRotation * easeProgress);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setAnimationActive(false);
      }
    };

    requestAnimationFrame(animate);
  };

  // Get color based on selection
  const getColor = () => {
    switch (selectedColor) {
      case 'red': return '#f87171';
      case 'blue': return '#60a5fa';
      case 'black': return '#6b7280';
      default: return '#f87171';
    }
  };

  // Get a more vibrant color for highlights
  const getVibrantColor = () => {
    switch (selectedColor) {
      case 'red': return '#ef4444';
      case 'blue': return '#3b82f6';
      case 'black': return '#4b5563';
      default: return '#ef4444';
    }
  };

  // Get glow effect class based on selected color
  const getGlowClass = () => {
    switch (selectedColor) {
      case 'red': return 'glow-effect-red';
      case 'blue': return 'glow-effect-blue';
      case 'black': return 'glow-effect';
      default: return 'glow-effect-red';
    }
  };

  // Validate GBT API key format
  const validateGbtApiKey = (key: string): boolean => {
    // GBT API keys typically start with "gbt-" followed by alphanumeric characters
    return /^gbt-[a-zA-Z0-9]{24,48}$/.test(key);
  };

  // Handle API key submission
  const handleApiKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Reset status while testing
    setApiStatus('disconnected');

    try {
      // Basic validation first
      if (!validateGbtApiKey(apiKey)) {
        alert('Invalid GBT API key format. Keys should start with "gbt-" followed by 24-48 characters.');
        setApiStatus('error');
        return;
      }

      // Simulate API test with delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // For demo, consider valid if it follows the format
      if (validateGbtApiKey(apiKey)) {
        setApiStatus('connected');
        setShowApiKeyInput(false);
        alert(`GBT API Key successfully connected: ${apiKey.substring(0, 6)}...${apiKey.substring(apiKey.length - 4)}`);
      } else {
        setApiStatus('error');
        alert('Could not connect to GBT API. Please check your key and try again.');
      }
    } catch (error) {
      console.error('Error testing API connection:', error);
      setApiStatus('error');
      alert('Error connecting to GBT API. Please try again later.');
    }
  };

  // The rest of the render function remains the same

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center">
      <div className="absolute top-0 left-0 right-0 flex justify-center gap-3 p-4 flex-wrap">
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedColor('red')}
            className={`px-4 py-2 rounded-lg transition-all shadow-lg ${
              selectedColor === 'red'
                ? 'bg-red-500 text-white font-medium border border-red-700'
                : 'bg-gray-800 text-red-400 hover:bg-gray-700 border border-red-900'
            }`}
          >
            Red SRG
          </button>
          <button
            onClick={() => setSelectedColor('blue')}
            className={`px-4 py-2 rounded-lg transition-all shadow-lg ${
              selectedColor === 'blue'
                ? 'bg-blue-500 text-white font-medium border border-blue-700'
                : 'bg-gray-800 text-blue-400 hover:bg-gray-700 border border-blue-900'
            }`}
          >
            Blue SRG
          </button>
          <button
            onClick={() => setSelectedColor('black')}
            className={`px-4 py-2 rounded-lg transition-all shadow-lg ${
              selectedColor === 'black'
                ? 'bg-gray-600 text-white font-medium border border-gray-500'
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-700'
            }`}
          >
            Black SRG
          </button>
        </div>

        <button
          onClick={() => setShowApiKeyInput(!showApiKeyInput)}
          className={`px-4 py-2 rounded-lg transition-all shadow-lg border ${
            apiStatus === 'connected'
              ? 'bg-green-600 text-white border-green-700 font-medium'
              : apiStatus === 'error'
                ? 'bg-red-600 text-white border-red-700 font-medium'
                : 'bg-yellow-600 hover:bg-yellow-700 text-white border-yellow-700 font-medium'
          }`}
        >
          {apiStatus === 'connected'
            ? 'GBT API Connected'
            : showApiKeyInput
              ? 'Hide GBT API Options'
              : 'GBT API Options'}
        </button>
      </div>

      {showApiKeyInput && (
        <div className="absolute top-20 right-4 z-10 bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 w-80">
          <h3 className="text-lg font-medium text-white mb-3">GBT API Integration</h3>
          <form onSubmit={handleApiKeySubmit} className="flex flex-col gap-3">
            <div>
              <label htmlFor="apiKey" className="text-sm text-gray-300 block mb-1">
                GBT API Key for SRG Pattern Generation
              </label>
              <input
                id="apiKey"
                type="text"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="gbt-xxxxxxxxxxxxxxxxxxxxxxxx"
                className="px-3 py-2 bg-gray-700 text-white rounded-md w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-400 mt-1">
                Enter your GBT API key to enable advanced pattern generation
              </p>
            </div>

            <div className="flex justify-between mt-3">
              <button
                type="submit"
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium"
              >
                Connect API
              </button>

              <button
                type="button"
                onClick={() => {
                  setApiKey('');
                  setApiStatus('disconnected');
                }}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
              >
                Reset
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="perspective-container mt-16">
        <svg
          width="500"
          height="500"
          viewBox="0 0 500 500"
          className={`
            visualization-transition
            ${animationActive ? getGlowClass() : ''}
          `}
        >
          {/* Add a subtle background grid for depth */}
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path
                d="M 20 0 L 0 0 0 20"
                fill="none"
                stroke={getColor()}
                strokeWidth="0.5"
                strokeOpacity="0.1"
              />
            </pattern>
          </defs>
          <rect width="500" height="500" fill="url(#grid)" fillOpacity="0.3" />

          <g className={animationActive ? 'animate-pulse' : ''}>
            {/* Enhanced Lines with varying thickness based on position */}
            {lines.map((line, index) => {
              // Calculate distance from center to determine opacity
              const dx = line.x2 - centerX;
              const dy = line.y2 - centerY;
              const distance = Math.sqrt(dx * dx + dy * dy);
              const maxDistance = 250; // Maximum expected distance
              const opacityFactor = Math.min(distance / maxDistance, 1);

              // Thickness based on distance - thinner for longer lines
              const thickness = 2.5 - (opacityFactor * 1);

              return (
                <line
                  key={`line-${index}`}
                  x1={line.x1}
                  y1={line.y1}
                  x2={line.x2}
                  y2={line.y2}
                  stroke={getColor()}
                  strokeWidth={thickness}
                  strokeOpacity={animationActive ? 0.9 : 0.7}
                  className="visualization-transition"
                />
              );
            })}

            {/* Enhanced Points with varying sizes based on position */}
            {points.map((point, index) => {
              // Calculate size based on digit value (if available) or position
              const digitValue = point.value !== undefined ? point.value : (index % 10);
              const sizeMultiplier = 0.8 + (digitValue / 10) * 1.2; // Range from 0.8 to 2.0
              const baseSize = index === 0 ? 8 : 5; // Center point is larger

              // Distance from center for glow effect
              const dx = point.x - centerX;
              const dy = point.y - centerY;
              const distance = Math.sqrt(dx * dx + dy * dy);
              const maxDistance = 250;
              const glowFactor = Math.min(distance / maxDistance, 1);

              return (
                <g key={`point-${index}`}>
                  {/* Glow effect for points */}
                  <circle
                    cx={point.x}
                    cy={point.y}
                    r={baseSize * sizeMultiplier * 1.8}
                    fill={getColor()}
                    fillOpacity={0.1 + (glowFactor * 0.1)}
                    className="visualization-transition"
                  />

                  {/* Main point */}
                  <circle
                    cx={point.x}
                    cy={point.y}
                    r={baseSize * sizeMultiplier}
                    fill={getVibrantColor()}
                    fillOpacity={animationActive ? 1 : 0.8}
                    className={`
                      visualization-transition
                      ${index === 0 ? 'calculator-button-pulse' : ''}
                    `}
                    style={{
                      animationDuration: '2s'
                    }}
                  />

                  {/* Add digit value in the center of points furthest from center */}
                  {index !== 0 && distance > 100 && point.value !== undefined && (
                    <text
                      x={point.x}
                      y={point.y}
                      textAnchor="middle"
                      dominantBaseline="central"
                      fill="white"
                      fontSize={10}
                      fontWeight="bold"
                    >
                      {point.value}
                    </text>
                  )}
                </g>
              );
            })}
          </g>

          {/* Number string indicator */}
          <text
            x={centerX}
            y="30"
            textAnchor="middle"
            fill={getColor()}
            className="font-bold"
            fontSize="16"
            strokeWidth="0.5"
            stroke={getColor()}
            paintOrder="stroke"
          >
            {selectedColor.toUpperCase()} SRG Pattern: {points.length} nodes
          </text>

          {/* API status indicator */}
          {apiStatus === 'connected' && (
            <g>
              <rect
                x={centerX - 70}
                y="40"
                width="140"
                height="24"
                rx="12"
                fill={getColor()}
                fillOpacity="0.2"
              />
              <text
                x={centerX}
                y="55"
                textAnchor="middle"
                fill="#10b981"
                className="font-bold"
                fontSize="12"
              >
                GBT API Connected
              </text>
              <circle
                cx={centerX - 55}
                cy="55"
                r="4"
                fill="#10b981"
                className="animate-pulse"
              />
            </g>
          )}
        </svg>
      </div>

      <div className="mt-4 text-center">
        <h3 className="text-xl font-bold text-white mb-2">
          {selectedColor.charAt(0).toUpperCase() + selectedColor.slice(1)} SRG - North Node Clockwise
        </h3>

        {/* Display a portion of the number string used for this color */}
        <div className="bg-gray-800 bg-opacity-90 p-3 rounded-lg max-w-2xl mx-auto border border-gray-700 shadow-lg mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-gray-400">Number Sequence:</span>
            <span className="text-xs text-gray-400">{numberStrings[selectedColor].length} digits</span>
          </div>
          <p className="text-sm font-mono tracking-wide" style={{ color: getColor() }}>
            {numberStrings[selectedColor].substring(0, 50)}...
          </p>
        </div>

        <div className="flex justify-center gap-4 flex-wrap">
          <button
            onClick={startAnimation}
            className={`px-6 py-3 rounded-lg bg-gradient-to-r font-medium text-white shadow-lg ${
              apiStatus === 'connected'
                ? 'from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 border border-green-700'
                : 'from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 border border-purple-700'
            }`}
            disabled={animationActive}
          >
            {animationActive ? 'Animating...' : 'Animate Pattern'}
          </button>

          <button
            onClick={() => setRotationAngle(prev => prev + (Math.PI / 8))}
            className="px-4 py-3 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-white shadow-lg font-medium border border-indigo-700"
            disabled={animationActive}
          >
            Rotate Clockwise
          </button>

          <button
            onClick={() => setRotationAngle(prev => prev - (Math.PI / 8))}
            className="px-4 py-3 bg-violet-600 hover:bg-violet-700 rounded-lg text-white shadow-lg font-medium border border-violet-700"
            disabled={animationActive}
          >
            Rotate Counter-Clockwise
          </button>
        </div>
      </div>
    </div>
  );
};

export default ClockwiseNodePattern;
