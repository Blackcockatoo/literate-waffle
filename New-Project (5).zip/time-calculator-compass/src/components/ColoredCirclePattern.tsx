import { useState, useEffect, useCallback, useMemo } from 'react';

// Define proper types for better TypeScript support
interface CircleData {
  x: number;
  y: number;
  radius: number;
  color: string;
  value?: number; // Optional digit value for display
}

const ColoredCirclePattern = () => {
  const [circles, setCircles] = useState<CircleData[]>([]);
  const [spiralActive, setSpiralActive] = useState(false);
  const [randomizeActive, setRandomizeActive] = useState(false);
  const [floatingActive, setFloatingActive] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [selectedNumberSet, setSelectedNumberSet] = useState<'blue' | 'red' | 'black'>('blue');
  const [apiStatus, setApiStatus] = useState<'disconnected' | 'connected' | 'error'>('disconnected');

  // Number strings that can be used for circle patterns
  const numberStrings = useMemo(() => ({
    blue: '012776329785893036118967145479098334781325217074992143965631',
    red: '113031491493585389543778774590997079619617525721567332336510',
    black: '011235831459437077415617853819099875279651673033695493257291'
  }), []);

  // Generate a random color
  const getRandomColor = useCallback(() => {
    const colors = [
      '#ef4444', // red
      '#f97316', // orange
      '#f59e0b', // amber
      '#84cc16', // lime
      '#10b981', // emerald
      '#06b6d4', // cyan
      '#3b82f6', // blue
      '#6366f1', // indigo
      '#8b5cf6', // violet
      '#d946ef', // fuchsia
      '#ec4899', // pink
      '#78716c', // stone
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }, []);

  // Get color based on selected number set
  const getBaseColor = useCallback(() => {
    switch (selectedNumberSet) {
      case 'blue': return '#3b82f6';
      case 'red': return '#ef4444';
      case 'black': return '#4b5563';
      default: return '#3b82f6';
    }
  }, [selectedNumberSet]);

  // Generate random circles using the number string as a seed
  const generateRandomCircles = useCallback(() => {
    const newCircles = [];
    const numberString = numberStrings[selectedNumberSet];

    // Use the number string to determine count
    const firstDigits = numberString.substring(0, 2);
    const count = 40 + Number(firstDigits) % 40;

    for (let i = 0; i < count; i++) {
      // Use digits from the number string to influence positions and sizes
      const digitPosition = i % numberString.length;
      const digit = Number(numberString[digitPosition]);
      const nextDigit = Number(numberString[(digitPosition + 1) % numberString.length]);

      const radiusVariation = (digit / 10) * 10 + 3; // 3-13 range
      const xRandomFactor = (nextDigit / 10); // 0-1 range
      const yRandomFactor = (Number(numberString[(digitPosition + 2) % numberString.length]) / 10); // 0-1 range

      const radius = radiusVariation;
      const x = radius + xRandomFactor * (500 - radius * 2);
      const y = radius + yRandomFactor * (500 - radius * 2);

      newCircles.push({
        x,
        y,
        radius,
        color: getRandomColor(),
        value: digit // Store the digit value for display
      });
    }

    setCircles(newCircles);
  }, [getRandomColor, numberStrings, selectedNumberSet]);

  // Generate spiral pattern using the number string for variations
  const generateSpiralPattern = useCallback(() => {
    const newCircles = [];
    const numberString = numberStrings[selectedNumberSet];

    // Use first digits to determine turns and count
    const firstDigit = Number(numberString[0]);
    const secondDigit = Number(numberString[1]);

    const turns = 1 + (firstDigit % 3); // 1-3 turns
    const count = 50 + secondDigit; // 50-59 circles
    const centerX = 250;
    const centerY = 250;

    // Large central spiral
    for (let i = 0; i < count; i++) {
      const digitPosition = i % numberString.length;
      const digit = Number(numberString[digitPosition]);

      // Use the digit to add variation to the angle and distance
      const angleVariation = (digit / 10) * 0.2; // 0-0.2 variation
      const angle = (i / count) * turns * Math.PI * 2 + angleVariation;

      const distanceVariation = (digit / 10) * 20; // 0-20 variation
      const distanceFromCenter = 20 + (i / count) * 180 + distanceVariation;

      const x = centerX + Math.cos(angle) * distanceFromCenter;
      const y = centerY + Math.sin(angle) * distanceFromCenter;

      const radiusVariation = (digit / 10) * 4 + 2; // 2-6 range
      const radius = radiusVariation;

      newCircles.push({
        x,
        y,
        radius,
        color: getRandomColor(),
        value: digit
      });
    }

    // Add some scattered circles around, using number string for positioning
    for (let i = 0; i < 30; i++) {
      const digitPosition = (count + i) % numberString.length;
      const digit = Number(numberString[digitPosition]);
      const nextDigit = Number(numberString[(digitPosition + 1) % numberString.length]);

      // Use digits to create angle and distance from center
      const angle = (digit / 10) * Math.PI * 2;
      const distanceFromCenter = 80 + (nextDigit / 10) * 170;

      const x = centerX + Math.cos(angle) * distanceFromCenter;
      const y = centerY + Math.sin(angle) * distanceFromCenter;

      const radius = 3 + (digit / 10) * 7; // 3-10 range

      newCircles.push({
        x,
        y,
        radius,
        color: getRandomColor(),
        value: digit
      });
    }

    setCircles(newCircles);
  }, [getRandomColor, numberStrings, selectedNumberSet]);

  // Generate a floating pattern with circles arranged using number string values
  const generateFloatingPattern = useCallback(() => {
    const newCircles = [];
    const numberString = numberStrings[selectedNumberSet];
    const centerX = 250;
    const centerY = 250;

    // Use first digits for ring count and variation
    const firstDigit = Number(numberString[0]);
    const ringCount = 3 + (firstDigit % 3); // 3-5 rings

    // Create rings of circles
    for (let ring = 0; ring < ringCount; ring++) {
      const ringPosition = ring % numberString.length;
      const ringDigit = Number(numberString[ringPosition]);

      const ringRadius = 40 + ring * 40 + (ringDigit * 5);
      const circlesInRing = 8 + ring * 4 + (ringDigit % 4);

      for (let i = 0; i < circlesInRing; i++) {
        const digitPosition = (ring * 10 + i) % numberString.length;
        const digit = Number(numberString[digitPosition]);

        // Add variation to angle based on the digit
        const angleVariation = (digit / 10) * 0.2 - 0.1; // -0.1 to 0.1
        const angle = (i / circlesInRing) * Math.PI * 2 + angleVariation;

        // Add variation to position based on digit
        const radiusVariation = (digit / 10) * 10 - 5; // -5 to 5
        const x = centerX + Math.cos(angle) * (ringRadius + radiusVariation);
        const y = centerY + Math.sin(angle) * (ringRadius + radiusVariation);

        const radius = 3 + (digit / 10) * 7 + ring; // Size increases with outer rings

        newCircles.push({
          x,
          y,
          radius,
          color: getRandomColor(),
          value: digit
        });
      }
    }

    // Add some random circles for variation
    for (let i = 0; i < 15; i++) {
      const digitPosition = (ringCount * 10 + i) % numberString.length;
      const digit = Number(numberString[digitPosition]);
      const nextDigit = Number(numberString[(digitPosition + 1) % numberString.length]);

      const angle = (digit / 10) * Math.PI * 2;
      const distanceFromCenter = (nextDigit / 10) * 230;

      const x = centerX + Math.cos(angle) * distanceFromCenter;
      const y = centerY + Math.sin(angle) * distanceFromCenter;

      const radius = 2 + (digit / 10) * 4;

      newCircles.push({
        x,
        y,
        radius,
        color: getRandomColor(),
        value: digit
      });
    }

    setCircles(newCircles);
  }, [getRandomColor, numberStrings, selectedNumberSet]);

  // Initialize with random circles
  useEffect(() => {
    generateRandomCircles();
  }, [generateRandomCircles]);

  // Validate GBT API key format
  const validateGbtApiKey = (key: string): boolean => {
    // GBT API keys typically start with "gbt-" followed by alphanumeric characters
    return /^gbt-[a-zA-Z0-9]{24,48}$/.test(key);
  };

  // Trigger spiral animation
  const triggerSpiral = () => {
    setSpiralActive(true);
    setRandomizeActive(false);
    setFloatingActive(false);

    // Simulate API request with the API key if connected
    if (apiStatus === 'connected') {
      console.log(`Simulating API request for spiral pattern with key: ${apiKey}`);
      // In a real implementation, you would make an actual API call here
    }

    generateSpiralPattern();

    setTimeout(() => {
      setSpiralActive(false);
    }, 5000);
  };

  // Trigger randomize animation
  const triggerRandomize = () => {
    setRandomizeActive(true);
    setSpiralActive(false);
    setFloatingActive(false);

    // Simulate API request with the API key if connected
    if (apiStatus === 'connected') {
      console.log(`Simulating API request for random pattern with key: ${apiKey}`);
      // In a real implementation, you would make an actual API call here
    }

    generateRandomCircles();

    setTimeout(() => {
      setRandomizeActive(false);
    }, 3000);
  };

  // Trigger floating pattern
  const triggerFloating = () => {
    setFloatingActive(true);
    setSpiralActive(false);
    setRandomizeActive(false);

    // Simulate API request with the API key if connected
    if (apiStatus === 'connected') {
      console.log(`Simulating API request for floating pattern with key: ${apiKey}`);
      // In a real implementation, you would make an actual API call here
    }

    generateFloatingPattern();

    setTimeout(() => {
      setFloatingActive(false);
    }, 4000);
  };

  // Handle API key submission
  const handleApiKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Reset status while testing
    setApiStatus('disconnected');

    try {
      // Basic validation first
      if (!validateGbtApiKey(apiKey)) {
        alert('Invalid GBT API key format. Keys should start with "gbt-" followed by 24-48 characters.');
        setApiStatus('error');
        return;
      }

      // Simulate API test with delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // For demo, consider valid if it follows the format
      if (validateGbtApiKey(apiKey)) {
        setApiStatus('connected');
        setShowApiKeyInput(false);
        alert(`GBT API Key successfully connected: ${apiKey.substring(0, 6)}...${apiKey.substring(apiKey.length - 4)}`);
      } else {
        setApiStatus('error');
        alert('Could not connect to GBT API. Please check your key and try again.');
      }
    } catch (error) {
      console.error('Error testing API connection:', error);
      setApiStatus('error');
      alert('Error connecting to GBT API. Please try again later.');
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center">
      <div className="absolute top-0 left-0 right-0 flex justify-center gap-3 p-4 flex-wrap">
        <div className="flex gap-2">
          <button
            onClick={triggerSpiral}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-white shadow-lg font-medium border border-indigo-700"
            disabled={spiralActive || randomizeActive || floatingActive}
          >
            Spiral Pattern
          </button>
          <button
            onClick={triggerRandomize}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-lg text-white shadow-lg font-medium border border-emerald-700"
            disabled={spiralActive || randomizeActive || floatingActive}
          >
            Random Pattern
          </button>
          <button
            onClick={triggerFloating}
            className="px-4 py-2 bg-violet-600 hover:bg-violet-700 rounded-lg text-white shadow-lg font-medium border border-violet-700"
            disabled={spiralActive || randomizeActive || floatingActive}
          >
            Floating Pattern
          </button>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setSelectedNumberSet('blue')}
            className={`px-4 py-2 rounded-lg transition-all shadow-md ${
              selectedNumberSet === 'blue'
                ? 'bg-blue-600 text-white font-medium border border-blue-700'
                : 'bg-gray-800 text-blue-300 hover:bg-gray-700 border border-blue-900'
            }`}
          >
            Blue Numbers
          </button>
          <button
            onClick={() => setSelectedNumberSet('red')}
            className={`px-4 py-2 rounded-lg transition-all shadow-md ${
              selectedNumberSet === 'red'
                ? 'bg-red-600 text-white font-medium border border-red-700'
                : 'bg-gray-800 text-red-300 hover:bg-gray-700 border border-red-900'
            }`}
          >
            Red Numbers
          </button>
          <button
            onClick={() => setSelectedNumberSet('black')}
            className={`px-4 py-2 rounded-lg transition-all shadow-md ${
              selectedNumberSet === 'black'
                ? 'bg-gray-600 text-white font-medium border border-gray-700'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
            }`}
          >
            Black Numbers
          </button>
        </div>

        <button
          onClick={() => setShowApiKeyInput(!showApiKeyInput)}
          className={`px-4 py-2 rounded-lg transition-all shadow-md border ${
            apiStatus === 'connected'
              ? 'bg-green-600 text-white border-green-700 font-medium'
              : apiStatus === 'error'
                ? 'bg-red-600 text-white border-red-700 font-medium'
                : 'bg-yellow-600 hover:bg-yellow-700 text-white border-yellow-700 font-medium'
          }`}
        >
          {apiStatus === 'connected'
            ? 'GBT API Connected'
            : showApiKeyInput
              ? 'Hide GBT API Options'
              : 'GBT API Options'}
        </button>
      </div>

      {/* Enhanced GBT API Key input section */}
      {showApiKeyInput && (
        <div className="absolute top-20 right-4 z-10 bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 w-80">
          <h3 className="text-lg font-medium text-white mb-3">GBT API Integration</h3>
          <form onSubmit={handleApiKeySubmit} className="flex flex-col gap-3">
            <div>
              <label htmlFor="apiKey" className="text-sm text-gray-300 block mb-1">
                GBT API Key for Circle Pattern Generation
              </label>
              <input
                id="apiKey"
                type="text"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="gbt-xxxxxxxxxxxxxxxxxxxxxxxx"
                className="px-3 py-2 bg-gray-700 text-white rounded-md w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-400 mt-1">
                Enter your GBT API key to enable advanced pattern generation
              </p>
            </div>

            <div className="flex justify-between mt-3">
              <button
                type="submit"
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium"
              >
                Connect API
              </button>

              <button
                type="button"
                onClick={() => {
                  setApiKey('');
                  setApiStatus('disconnected');
                }}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg"
              >
                Reset
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="perspective-container mt-16">
        <svg
          width="500"
          height="500"
          viewBox="0 0 500 500"
          className={`
            visualization-transition
            ${spiralActive ? 'rotateY-animation' : ''}
            ${randomizeActive ? 'animate-pulse' : ''}
            ${floatingActive ? 'glow-effect' : ''}
          `}
          style={spiralActive ? { animationDuration: '20s' } : {}}
        >
          {/* Add subtle background patterns */}
          <defs>
            <pattern id="smallGrid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path
                d="M 10 0 L 0 0 0 10"
                fill="none"
                stroke={getBaseColor()}
                strokeWidth="0.5"
                strokeOpacity="0.1"
              />
            </pattern>
          </defs>
          <rect width="500" height="500" fill="url(#smallGrid)" fillOpacity="0.3" />

          {/* Enhanced circles with better visual effects */}
          {circles.map((circle, index) => {
            // Calculate distance from center for effects
            const centerX = 250;
            const centerY = 250;
            const dx = circle.x - centerX;
            const dy = circle.y - centerY;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const maxDistance = 250;
            const distanceFactor = Math.min(distance / maxDistance, 1);

            // Create unique animation delay based on position and index
            const animDelay = ((index % 10) * 200) + (distanceFactor * 1000);

            // Determine if this circle should show its value (digit)
            const showValue = circle.radius > 6 && circle.value !== undefined && Math.random() > 0.7;

            return (
              <g
                key={`circle-${index}`}
                className="visualization-transition"
              >
                {/* Outer glow effect */}
                <circle
                  cx={circle.x}
                  cy={circle.y}
                  r={circle.radius * 1.5}
                  fill={circle.color}
                  fillOpacity={0.1}
                  className={randomizeActive ? 'animate-ping' : ''}
                  style={{
                    animationDelay: `${animDelay}ms`,
                    animationDuration: randomizeActive ? `${1 + Math.random()}s` : '2s'
                  }}
                />

                {/* Main circle with better visual styling */}
                <circle
                  cx={circle.x}
                  cy={circle.y}
                  r={circle.radius}
                  fill="none"
                  stroke={circle.color}
                  strokeWidth={randomizeActive ? 2 : 1.5}
                  className={`
                    time-circle
                    ${randomizeActive ? 'animate-ping' : ''}
                    ${floatingActive ? 'calculator-button-pulse' : ''}
                  `}
                  style={{
                    animationDelay: `${animDelay}ms`,
                    animationDuration: randomizeActive
                      ? `${0.5 + Math.random() * 2}s`
                      : `${1 + Math.random()}s`
                  }}
                />

                {/* Inner circle with fill for better visibility */}
                <circle
                  cx={circle.x}
                  cy={circle.y}
                  r={circle.radius * 0.4}
                  fill={circle.color}
                  fillOpacity={0.7}
                />

                {/* Display number value inside some circles */}
                {showValue && (
                  <text
                    x={circle.x}
                    y={circle.y}
                    textAnchor="middle"
                    dominantBaseline="central"
                    fill="white"
                    fontSize={circle.radius * 0.7}
                    fontWeight="bold"
                  >
                    {circle.value}
                  </text>
                )}
              </g>
            );
          })}

          {/* Header showing current mode and number set */}
          <g>
            <rect
              x="100"
              y="20"
              width="300"
              height="30"
              rx="15"
              fill={getBaseColor()}
              fillOpacity="0.15"
              stroke={getBaseColor()}
              strokeWidth="1"
              strokeOpacity="0.3"
            />
            <text
              x="250"
              y="40"
              textAnchor="middle"
              className="font-bold"
              fill={getBaseColor()}
              fontSize="16"
            >
              {selectedNumberSet.toUpperCase()} Number Pattern: {circles.length} circles
            </text>
          </g>

          {/* API status indicator */}
          {apiStatus === 'connected' && (
            <g>
              <rect
                x="180"
                y="60"
                width="140"
                height="24"
                rx="12"
                fill={getBaseColor()}
                fillOpacity="0.2"
              />
              <text
                x="250"
                y="75"
                textAnchor="middle"
                className="font-bold"
                fill="#10b981"
                fontSize="12"
              >
                GBT API Connected
              </text>
              <circle
                cx="205"
                cy="75"
                r="4"
                fill="#10b981"
                className="animate-pulse"
              />
            </g>
          )}
        </svg>
      </div>

      <div className="mt-4 text-center">
        <h3 className="text-xl font-bold text-white mb-2">
          {spiralActive
            ? 'Spiral Harmony Integration'
            : randomizeActive
              ? 'Random Pattern Distribution'
              : floatingActive
                ? 'Floating Pattern Formation'
                : 'Multivariate Circle Distribution Analysis'}
        </h3>

        {/* Display the number sequence being used */}
        <div className="bg-gray-800 bg-opacity-90 p-3 rounded-lg max-w-2xl mx-auto border border-gray-700 shadow-lg mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-gray-400">Number Sequence:</span>
            <span className="text-xs text-gray-400">{numberStrings[selectedNumberSet].length} digits</span>
          </div>
          <p className="text-sm font-mono tracking-wide" style={{ color: getBaseColor() }}>
            {numberStrings[selectedNumberSet].substring(0, 50)}...
          </p>
        </div>

        {/* Status information about current pattern */}
        <p className="text-gray-300 text-sm mt-2 mb-4">
          Active circles: {circles.length} |
          Current mode: {
            spiralActive ? "Spiral" :
            randomizeActive ? "Random" :
            floatingActive ? "Floating" : "Static"
          } |
          Number set: {selectedNumberSet.toUpperCase()}
        </p>

        {/* Pattern selection buttons in footer */}
        <div className="flex justify-center gap-3 flex-wrap">
          <button
            onClick={triggerRandomize}
            className="px-5 py-3 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg font-medium border border-emerald-700"
            disabled={spiralActive || randomizeActive || floatingActive}
          >
            Generate Random Pattern
          </button>

          <button
            onClick={triggerSpiral}
            className="px-5 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white shadow-lg font-medium border border-indigo-700"
            disabled={spiralActive || randomizeActive || floatingActive}
          >
            Create Spiral Pattern
          </button>

          <button
            onClick={triggerFloating}
            className="px-5 py-3 rounded-lg bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white shadow-lg font-medium border border-violet-700"
            disabled={spiralActive || randomizeActive || floatingActive}
          >
            Form Floating Pattern
          </button>
        </div>
      </div>
    </div>
  );
};

export default ColoredCirclePattern;
