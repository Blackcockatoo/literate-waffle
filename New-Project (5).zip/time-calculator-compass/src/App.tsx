import { useState } from 'react';
import TimeCompass from './components/TimeCompass';
import ClockwiseNodePattern from './components/ClockwiseNodePattern';
import ColoredCirclePattern from './components/ColoredCirclePattern';
import PatternSelector from './components/PatternSelector';

function App() {
  const [selectedPattern, setSelectedPattern] = useState<string>('timeCompass');

  return (
    <div className="min-h-screen bg-gray-900 text-white p-2 md:p-4">
      <header className="container mx-auto mb-4 md:mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-center bg-gradient-to-r from-blue-400 via-purple-500 to-red-500 bg-clip-text text-transparent py-2 md:py-4">
          Temporal Mathematics Compass
        </h1>
        <p className="text-center text-gray-400 max-w-2xl mx-auto text-sm md:text-base">
          A special time calculator compass based on circular numeric patterns and mathematical principles
        </p>
      </header>

      <main className="container mx-auto flex flex-col items-center">
        <div className="w-full max-w-md mb-4">
          <PatternSelector
            selectedPattern={selectedPattern}
            setSelectedPattern={setSelectedPattern}
          />
        </div>

        <div className="w-full max-w-md aspect-square my-2 md:my-8 flex items-center justify-center">
          {selectedPattern === 'timeCompass' && <TimeCompass />}
          {selectedPattern === 'nodePattern' && <ClockwiseNodePattern />}
          {selectedPattern === 'circlePattern' && <ColoredCirclePattern />}
        </div>
      </main>

      <footer className="mt-4 text-center text-gray-500 text-xs">
        <p>© {new Date().getFullYear()} Temporal Mathematics Compass</p>
      </footer>
    </div>
  );
}

export default App;
