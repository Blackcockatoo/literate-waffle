
# Circle Theory Calculator — Insight Explorer (Starter)

Zero-friction SPA to visualize 60×60 heatmaps (sum-10 zeros, bit-hex XOR zeros) and surface insights.
Drop CSVs in `public/data` (see schemas in CODEX_MAP) and run.

## Quickstart
```bash
npm install
npm run dev
# or: bun install && bun dev
```

## Data files expected (public/data)
- heatmap_all_pairs_sum10zeros_long.csv
- heatmap_all_pairs_bithexzeros_long.csv
- energy_summary.csv
- energy_rotations.csv
- energy_positions.csv
- energy_runs.csv
- rolling_probable_primes.csv
