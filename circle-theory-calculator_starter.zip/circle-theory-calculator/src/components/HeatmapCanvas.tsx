
import React, { useEffect, useRef } from 'react'

type Props = {
  matrix: number[][] | null
  highlightRotation?: number
}

export const HeatmapCanvas: React.FC<Props> = ({ matrix, highlightRotation }) => {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = ref.current
    if (!canvas || !matrix) return
    const rows = matrix.length
    const cols = matrix[0].length
    const scale = 6 // pixels per cell
    canvas.width = cols * scale
    canvas.height = rows * scale
    const ctx = canvas.getContext('2d')!
    ctx.clearRect(0,0,canvas.width,canvas.height)
    // draw cells
    for (let r=0;r<rows;r++){
      for (let c=0;c<cols;c++){
        const v = matrix[r][c]
        // 0 -> transparent dark; 1 -> bright cyan
        ctx.fillStyle = v ? '#00f7ff' : '#0f172a' // slate-900
        ctx.fillRect(c*scale, r*scale, scale, scale)
      }
    }
    if (highlightRotation != null){
      ctx.fillStyle = 'rgba(184,155,47,0.25)' // gold overlay
      ctx.fillRect(0, highlightRotation*scale, cols*scale, scale)
    }
  }, [matrix, highlightRotation])
  return <canvas ref={ref} className="w-full rounded-xl border border-slate-800" />
}
