
import React from 'react'

type Insights = {
  byRotation: { rotation:number, zeros:number }[]
  byPosition: { position:number, zeros:number }[]
  runs: { rotation:number, maxRun:number }[]
  cluster: number
} | null

export const InsightPanel: React.FC<{insights: Insights}> = ({ insights }) => {
  if (!insights) return <div>Loading…</div>
  const topR = [...insights.byRotation].sort((a,b)=>b.zeros-a.zeros).slice(0,5)
  const topP = [...insights.byPosition].sort((a,b)=>b.zeros-a.zeros).slice(0,10)
  const topRuns = [...insights.runs].sort((a,b)=>b.maxRun-a.maxRun).slice(0,5)
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Insights</h2>
      <div>
        <h3 className="font-medium text-slate-300 mb-1">Top rotations</h3>
        <ul className="text-sm space-y-1">
          {topR.map(r=> <li key={r.rotation}>r={r.rotation}: {r.zeros} zeros</li>)}
        </ul>
      </div>
      <div>
        <h3 className="font-medium text-slate-300 mb-1">Anchor positions</h3>
        <ul className="text-sm space-y-1">
          {topP.map(p=> <li key={p.position}>pos {p.position}: {p.zeros} zeros</li>)}
        </ul>
      </div>
      <div>
        <h3 className="font-medium text-slate-300 mb-1">Longest runs</h3>
        <ul className="text-sm space-y-1">
          {topRuns.map(r=> <li key={r.rotation}>r={r.rotation}: run {r.maxRun}</li>)}
        </ul>
      </div>
      <div className="text-sm">
        <span className="text-slate-400">Largest cluster:</span> {insights.cluster}
      </div>
    </div>
  )
}
