
import React from 'react'

type Props = {
  pairs: string[]
  modes: string[]
  pair: string
  mode: string
  onPair: (v: string) => void
  onMode: (v: string) => void
  rotation: number | null
  onRotation: (v: number | null) => void
}

export const Controls: React.FC<Props> = ({ pairs, modes, pair, mode, onPair, onMode, rotation, onRotation }) => {
  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 grid gap-3 md:grid-cols-4 items-end">
      <div>
        <label className="block text-sm text-slate-300 mb-1">Pair</label>
        <select value={pair} onChange={e=>onPair(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1">
          {pairs.map(p=>(<option key={p} value={p}>{p}</option>))}
        </select>
      </div>
      <div>
        <label className="block text-sm text-slate-300 mb-1">Mode</label>
        <select value={mode} onChange={e=>onMode(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1">
          {modes.map(m=>(<option key={m} value={m}>{m}</option>))}
        </select>
      </div>
      <div className="md:col-span-2">
        <label className="block text-sm text-slate-300 mb-1">Rotation spotlight (0–59)</label>
        <input type="range" min={0} max={59} value={rotation ?? 0} onChange={e=>onRotation(parseInt(e.target.value))} className="w-full" />
      </div>
    </div>
  )
}
