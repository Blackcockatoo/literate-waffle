
export type PrimeRow = {
  sequence: string
  window_size: number
  start_index_1b: number
  slice: string
  is_probable_prime: number
}

// density at each position (1..60) based on windows that cover that position
export function densityByPosition(rows: PrimeRow[], seqName: string){
  const filtered = rows.filter(r=>r.sequence===seqName)
  const coverCount = Array(60).fill(0)
  const primeCount = Array(60).fill(0)
  for (const r of filtered){
    const start = r.start_index_1b
    const end = r.start_index_1b + r.window_size - 1
    for (let pos=start; pos<=end && pos<=60; pos++){
      coverCount[pos-1]++
      if (r.is_probable_prime) primeCount[pos-1]++
    }
  }
  return Array.from({length:60}, (_,i)=> (coverCount[i] ? primeCount[i]/coverCount[i] : 0))
}
