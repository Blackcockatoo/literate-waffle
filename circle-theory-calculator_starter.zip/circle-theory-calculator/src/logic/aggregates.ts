
export function zerosPerRotation(matrix: number[][]){
  const out: {rotation:number, zeros:number}[] = []
  for (let r=0;r<matrix.length;r++){
    let s=0; for (let c=0;c<matrix[r].length;c++) s+=matrix[r][c]
    out.push({ rotation:r, zeros:s })
  }
  return out
}

export function zerosPerPosition(matrix: number[][]){
  const rows = matrix.length, cols = matrix[0].length
  const out: {position:number, zeros:number}[] = []
  for (let c=0;c<cols;c++){
    let s=0; for (let r=0;r<rows;r++) s+=matrix[r][c]
    out.push({ position:c+1, zeros:s })
  }
  return out
}

export function longestRunPerRotation(matrix: number[][]){
  const out: {rotation:number, maxRun:number}[] = []
  for (let r=0;r<matrix.length;r++){
    let run=0, mx=0
    for (let c=0;c<matrix[r].length;c++){
      if (matrix[r][c]===1){ run++; if (run>mx) mx=run } else { run=0 }
    }
    out.push({ rotation:r, maxRun: mx })
  }
  return out
}

export function largestClusterSize(matrix: number[][]){
  const H = matrix.length, W = matrix[0].length
  const seen = Array.from({length:H}, ()=> Array(W).fill(false))
  let best=0
  const q: [number,number][] = []
  const push = (x:number,y:number)=>{ q.push([x,y]); seen[x][y]=True as any }
  // Typescript doesn't like True; just write JS style below.
  function bfs(sx:number, sy:number){
    let size=0
    const dq: [number,number][] = [[sx,sy]]
    seen[sx][sy]=true
    while (dq.length){
      const [x,y] = dq.shift()!
      size++
      const nbrs = [[1,0],[-1,0],[0,1],[0,-1]]
      for (const [dx,dy] of nbrs){
        const nx=x+dx, ny=y+dy
        if (nx>=0 && nx<H && ny>=0 && ny<W && !seen[nx][ny] && matrix[nx][ny]===1){
          seen[nx][ny]=true; dq.push([nx,ny])
        }
      }
    }
    return size
  }
  for (let i=0;i<H;i++){
    for (let j=0;j<W;j++){
      if (matrix[i][j]===1 && !seen[i][j]){
        const s = bfs(i,j)
        if (s>best) best=s
      }
    }
  }
  return best
}
