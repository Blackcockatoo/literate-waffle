
import Papa from 'papaparse'

export type HeatmapRowLong = {
  pair: string
  mode: string
  rotation: number
  position: number
  zero_flag: number
}

export async function loadCSV<T=any>(url: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    Papa.parse<T>(url, {
      download: true,
      header: true,
      dynamicTyping: true,
      fastMode: true,
      complete: (res) => resolve(res.data as T[]),
      error: reject,
    })
  })
}

export async function loadHeatmapLong(url: string): Promise<HeatmapRowLong[]> {
  const rows = await loadCSV<HeatmapRowLong>(url)
  // basic sanitize
  return rows.filter(r=> r && typeof r.rotation==='number' && typeof r.position==='number' && typeof r.zero_flag==='number')
}

export function pivotToMatrix(rows: HeatmapRowLong[]): number[][] | null {
  if (!rows.length) return null
  const matrix = Array.from({length:60}, ()=> Array(60).fill(0))
  for (const r of rows) {
    if (r.rotation>=0 && r.rotation<60 && r.position>=1 && r.position<=60){
      matrix[r.rotation][r.position-1] = r.zero_flag ? 1 : 0
    }
  }
  return matrix
}

export async function loadEnergyTables(base: string){
  const [summary, rot, pos, runs] = await Promise.all([
    loadCSV(base + '/energy_summary.csv'),
    loadCSV(base + '/energy_rotations.csv'),
    loadCSV(base + '/energy_positions.csv'),
    loadCSV(base + '/energy_runs.csv'),
  ])
  return { summary, rot, pos, runs }
}
