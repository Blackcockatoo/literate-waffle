
import React, { useEffect, useMemo, useState } from 'react'
import { Controls } from './components/Controls'
import { HeatmapCanvas } from './components/HeatmapCanvas'
import { InsightPanel } from './components/InsightPanel'
import { loadHeatmapLong, pivotToMatrix, loadEnergyTables, type HeatmapRowLong } from './data/loaders'
import { zerosPerRotation, zerosPerPosition, longestRunPerRotation, largestClusterSize } from './logic/aggregates'

const MODES = ['sum10_zero','bithex_zero'] as const
type Mode = typeof MODES[number]

const PAIRS = [
  'Red60-Blue60','Red60-Black60','Red60-Lukus60',
  'Black60-Blue60','Black60-Lukus60','Blue60-Lukus60'
] as const
type Pair = typeof PAIRS[number]

export default function App() {
  const [pair, setPair] = useState<Pair>('Red60-Blue60')
  const [mode, setMode] = useState<Mode>('sum10_zero')
  const [rotationSpotlight, setRotationSpotlight] = useState<number | null>(null)

  const [rowsSum, setRowsSum] = useState<HeatmapRowLong[]>([])
  const [rowsHex, setRowsHex] = useState<HeatmapRowLong[]>([])
  const [energy, setEnergy] = useState(null as any)

  useEffect(() => {
    Promise.all([
      loadHeatmapLong('/data/heatmap_all_pairs_sum10zeros_long.csv'),
      loadHeatmapLong('/data/heatmap_all_pairs_bithexzeros_long.csv'),
      loadEnergyTables('/data')
    ]).then(([sumRows, hexRows, energyTables]) => {
      setRowsSum(sumRows); setRowsHex(hexRows); setEnergy(energyTables)
    })
  }, [])

  const matrix = useMemo(() => {
    const source = mode === 'sum10_zero' ? rowsSum : rowsHex
    const filtered = source.filter(r => r.pair === pair)
    return pivotToMatrix(filtered)
  }, [rowsSum, rowsHex, pair, mode])

  const insights = useMemo(() => {
    if (!matrix) return null
    return {
      byRotation: zerosPerRotation(matrix),
      byPosition: zerosPerPosition(matrix),
      runs: longestRunPerRotation(matrix),
      cluster: largestClusterSize(matrix)
    }
  }, [matrix])

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-4 p-4">
      <div className="space-y-4">
        <Controls
          pairs={PAIRS as unknown as string[]}
          modes={MODES as unknown as string[]}
          pair={pair} mode={mode}
          onPair={p=>setPair(p as Pair)}
          onMode={m=>setMode(m as Mode)}
          rotation={rotationSpotlight}
          onRotation={setRotationSpotlight}
        />
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <HeatmapCanvas matrix={matrix} highlightRotation={rotationSpotlight ?? undefined} />
        </div>
      </div>
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
        <InsightPanel insights={insights} />
      </div>
    </div>
  )
}
