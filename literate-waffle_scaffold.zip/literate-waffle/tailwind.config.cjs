
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        midnight: "#0a0f1f",
        gold: "#b89b2f",
        neon: "#00f7ff"
      }
    },
  },
  plugins: [],
};
