
import Papa from 'papaparse'

export type HeatmapRowLong = {
  pair: string
  mode: string
  rotation: number
  position: number
  zero_flag: number
}

export async function loadCSV<T=any>(url: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    Papa.parse<T>(url, {
      download: true,
      header: true,
      dynamicTyping: true,
      fastMode: true,
      complete: (res) => resolve(res.data as T[]),
      error: reject,
    })
  })
}

export async function loadHeatmapLong(url: string): Promise<HeatmapRowLong[]> {
  const rows = await loadCSV<HeatmapRowLong>(url)
  return rows.filter(r => r && typeof r.rotation==='number' && typeof r.position==='number' && typeof r.zero_flag==='number')
}

export function rowToRotationOverlay(rows: HeatmapRowLong[], pair: string, mode: string, rotation: number): number[] {
  const row = rows.filter(r => r.pair===pair && r.mode===mode && r.rotation===rotation)
  const overlay = Array(60).fill(0)
  for (const r of row){
    if (r.position>=1 && r.position<=60) overlay[r.position-1] = r.zero_flag ? 1 : 0
  }
  return overlay
}

export async function loadTopRotations(url: string){
  try {
    const rows = await loadCSV<any>(url)
    return rows
  } catch {
    return []
  }
}
