
import React, { useMemo, useRef } from 'react'

type Props = {
  numberString: string
  rotationRad: number
  color: string
  overlay?: number[] // length 60, 1=tint highlight
}

export const TimeCompass: React.FC<Props> = ({ numberString, rotationRad, color, overlay }) => {
  const N = numberString.length
  const digits = useMemo(()=> numberString.split('').map(d=> parseInt(d,10)), [numberString])
  const cx = 200, cy = 200, r = 150
  const svgRef = useRef<SVGSVGElement>(null)

  const points = useMemo(()=> {
    return Array.from({length:N}, (_,i)=> {
      const theta = i * (2*Math.PI/N) + rotationRad
      const x = cx + r * Math.cos(theta)
      const y = cy + r * Math.sin(theta)
      const d = digits[i] || 0
      const size = 0.8 + (d/10)*0.6
      return { i, x, y, d, size }
    })
  }, [N, rotationRad, digits])

  const exportPNG = () => {
    const svg = svgRef.current
    if (!svg) return
    const xml = new XMLSerializer().serializeToString(svg)
    const svg64 = btoa(unescape(encodeURIComponent(xml)))
    const img = new Image()
    img.onload = () => {
      const canvas = document.createElement('canvas')
      canvas.width = 400; canvas.height = 400
      const ctx = canvas.getContext('2d')!
      ctx.fillStyle = '#0a0f1f'; ctx.fillRect(0,0,400,400)
      ctx.drawImage(img, 0, 0)
      const link = document.createElement('a')
      link.download = 'time-compass.png'
      link.href = canvas.toDataURL('image/png')
      link.click()
    }
    img.src = 'data:image/svg+xml;base64,' + svg64
  }

  return (
    <div className="space-y-2">
      <svg ref={svgRef} width={400} height={400} viewBox="0 0 400 400">
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* rings */}
        <circle cx={cx} cy={cy} r={r} stroke={color} strokeWidth={2} fill="none" />
        <circle cx={cx} cy={cy} r={r-30} stroke={color} strokeOpacity={0.25} strokeDasharray="6 6" fill="none" />

        {/* points */}
        {points.map(p => {
          const isHot = overlay && overlay[p.i]===1
          const fill = isHot ? '#00f7ff' : color
          const opacity = isHot ? 1 : 0.9
          const radius = (isHot ? 4 : 3) * p.size
          return (
            <g key={p.i} filter="url(#glow)">
              <circle cx={p.x} cy={p.y} r={radius} fill={fill} fillOpacity={opacity} />
            </g>
          )
        })}

        {/* indices every 5 */}
        {points.filter(p => p.i % 5 === 0).map(p => (
          <text key={'idx'+p.i} x={p.x} y={p.y} dy={-8} fontSize={10} textAnchor="middle" fill="#94a3b8">{p.i+1}</text>
        ))}
      </svg>

      <div className="flex gap-2">
        <button onClick={exportPNG} className="px-3 py-1 rounded bg-slate-800 border border-slate-700 hover:bg-slate-700">Export PNG</button>
      </div>
    </div>
  )
}
