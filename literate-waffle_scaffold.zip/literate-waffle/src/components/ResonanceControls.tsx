
import React from 'react'

type Props = {
  pair: string
  mode: string
  rotation: number
  onPair: (v:string)=>void
  onMode: (v:string)=>void
  onRotation: (v:number)=>void
  topRotations?: {rotation:number, zeros_per_rotation:number}[]
  onSnapTop?: ()=>void
}

export const ResonanceControls: React.FC<Props> = ({ pair, mode, rotation, onPair, onMode, onRotation, topRotations, onSnapTop }) => {
  const pairs = ['Red60-Blue60','Red60-Black60','Red60-Lukus60','Black60-Blue60','Black60-Lukus60','Blue60-Lukus60']
  const modes = ['sum10_zero','bithex_zero']
  return (
    <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 grid gap-3 md:grid-cols-4 items-end">
      <div>
        <label className="block text-xs text-slate-400 mb-1">Pair</label>
        <select className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1" value={pair} onChange={e=>onPair(e.target.value)}>
          {pairs.map(p=> <option key={p} value={p}>{p}</option>)}
        </select>
      </div>
      <div>
        <label className="block text-xs text-slate-400 mb-1">Mode</label>
        <select className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1" value={mode} onChange={e=>onMode(e.target.value)}>
          {modes.map(m=> <option key={m} value={m}>{m}</option>)}
        </select>
      </div>
      <div className="md:col-span-2">
        <label className="block text-xs text-slate-400 mb-1">Rotation (6° steps)</label>
        <input className="w-full" type="range" min={0} max={59} value={rotation} onChange={e=>onRotation(parseInt(e.target.value))} />
      </div>
      <div className="md:col-span-4 flex items-center gap-2 text-xs text-slate-400">
        <button onClick={onSnapTop} className="px-2 py-1 rounded bg-slate-800 border border-slate-700 hover:bg-slate-700">Snap to Top Rotation</button>
        {topRotations && topRotations.length>0 && <span>Top: r={topRotations[0].rotation} ({topRotations[0].zeros_per_rotation})</span>}
      </div>
    </div>
  )
}
