
import React, { useEffect, useMemo, useState } from 'react'
import { TimeCompass } from './components/TimeCompass'
import { ResonanceControls } from './components/ResonanceControls'
import { loadHeatmapLong, loadTopRotations, rowToRotationOverlay, type HeatmapRowLong } from './data/loaders'

const COLORS: Record<string,string> = { blue:'#3b82f6', red:'#ef4444', black:'#4b5563' }
const SEQS: Record<string,string> = {
  blue: '012776329785893036118967145479098334781325217074992143965631',
  red: '113031491493585389543778774590997079619617525721567332336510',
  black: '011235831459437077415617853819099875279651673033695493257291'
}

export default function App() {
  const [pair, setPair] = useState('Red60-Blue60')
  const [mode, setMode] = useState('sum10_zero')
  const [rotation, setRotation] = useState(0)
  const [sumRows, setSumRows] = useState<HeatmapRowLong[]>([])
  const [hexRows, setHexRows] = useState<HeatmapRowLong[]>([])
  const [top, setTop] = useState<any[]>([])

  useEffect(()=> {
    Promise.all([
      loadHeatmapLong('/data/heatmap_all_pairs_sum10zeros_long.csv'),
      loadHeatmapLong('/data/heatmap_all_pairs_bithexzeros_long.csv'),
      loadTopRotations('/data/energy_rotations.csv')
    ]).then(([sum, hex, topR])=> { setSumRows(sum); setHexRows(hex); setTop(topR) })
  }, [])

  const overlay = useMemo(()=> {
    const rows = mode==='sum10_zero' ? sumRows : hexRows
    return rowToRotationOverlay(rows, pair, mode, rotation)
  }, [pair, mode, rotation, sumRows, hexRows])

  const [leftKey, rightKey] = pair.split('-').map(s => s.replace('60','').toLowerCase())

  return (
    <div className="min-h-screen p-4 space-y-4">
      <header className="flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-wide">literate-waffle — Insight Explorer</h1>
      </header>
      <ResonanceControls
        pair={pair} mode={mode} rotation={rotation}
        onPair={setPair} onMode={setMode} onRotation={setRotation}
        topRotations={top.filter(r=>r.pair===pair && r.mode===mode).sort((a:any,b:any)=>b.zeros_per_rotation-a.zeros_per_rotation)}
        onSnapTop={()=> {
          const best = top.filter(r=>r.pair===pair && r.mode===mode).sort((a:any,b:any)=>b.zeros_per_rotation-a.zeros_per_rotation)[0]
          if (best) setRotation(best.rotation)
        }}
      />
      <div className="grid md:grid-cols-2 gap-4">
        <TimeCompass numberString={SEQS[leftKey]} rotationRad={rotation*(Math.PI/30)} color={COLORS[leftKey]} overlay={overlay} />
        <TimeCompass numberString={SEQS[rightKey]} rotationRad={rotation*(Math.PI/30)} color={COLORS[rightKey]} overlay={overlay} />
      </div>
    </div>
  )
}
