
# literate-waffle — Insight Explorer

A lightweight SPA that visualizes 60×60 resonance heatmaps and overlays them onto a circular compass built from your numeric sequences.

## Quickstart
```bash
npm install
npm run dev
# or: bun install && bun dev
```

## Data files expected (public/data)
- heatmap_all_pairs_sum10zeros_long.csv
- heatmap_all_pairs_bithexzeros_long.csv
- energy_rotations.csv
(Drop your real CSV exports here; placeholder files are included so the app boots.)

## Features
- Pair & mode selector (sum‑10 zero / bit‑hex zero)
- Rotation slider (6° steps); **Snap to Top** from energy table
- Overlay highlights hot positions on the compass
- Export PNG of the current view

## Deploy
Netlify-ready (SPA redirects). Build with:
```bash
npm run build
```
